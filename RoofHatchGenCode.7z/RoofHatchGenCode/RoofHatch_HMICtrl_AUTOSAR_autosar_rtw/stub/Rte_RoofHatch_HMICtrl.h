/* This file contains stub implementations of the AUTOSAR RTE functions.
   The stub implementations can be used for testing the generated code in
   Simulink, for example, in SIL/PIL simulations of the component under
   test. Note that this file should be replaced with an appropriate RTE
   file when deploying the generated code outside of Simulink.

   This file is generated for:
   Atomic software component:  "RoofHatch_HMICtrl"
   ARXML schema: "4.0"
   File generated on: "13-Nov-2018 15:20:06"  */

#ifndef Rte_RoofHatch_HMICtrl_h
#define Rte_RoofHatch_HMICtrl_h
#include "Rte_Type.h"
#include "Compiler.h"

/* Data access functions */
#define Rte_Read_BunkH1RoofhatchCloseBtn_Stat_PushButtonStatus Rte_Read_RoofHatch_HMICtrl_BunkH1RoofhatchCloseBtn_Stat_PushButtonStatus

Std_ReturnType Rte_Read_BunkH1RoofhatchCloseBtn_Stat_PushButtonStatus(uint8* u);

#define Rte_Read_BunkH1RoofhatchOpenBtn_Stat_PushButtonStatus Rte_Read_RoofHatch_HMICtrl_BunkH1RoofhatchOpenBtn_Stat_PushButtonStatus

Std_ReturnType Rte_Read_BunkH1RoofhatchOpenBtn_Stat_PushButtonStatus(uint8* u);

#define Rte_Read_RoofHatch_SwitchStatus_A3PosSwitchStatus Rte_Read_RoofHatch_HMICtrl_RoofHatch_SwitchStatus_A3PosSwitchStatus

Std_ReturnType Rte_Read_RoofHatch_SwitchStatus_A3PosSwitchStatus(uint8* u);

#define Rte_Read_Vmode_Vmode           Rte_Read_RoofHatch_HMICtrl_Vmode_Vmode

Std_ReturnType Rte_Read_Vmode_Vmode(uint8* u);

#define Rte_Write_RoofHatch_HMI_rqst_RoofHatch_HMI_rqst Rte_Write_RoofHatch_HMICtrl_RoofHatch_HMI_rqst_RoofHatch_HMI_rqst

Std_ReturnType Rte_Write_RoofHatch_HMI_rqst_RoofHatch_HMI_rqst(uint8 u);

#define Rte_Invalidate_RoofHatch_HMI_rqst_RoofHatch_HMI_rqst Rte_Invalidate_RoofHatch_HMICtrl_RoofHatch_HMI_rqst_RoofHatch_HMI_rqst

Std_ReturnType Rte_Invalidate_RoofHatch_HMI_rqst_RoofHatch_HMI_rqst(void);

/* Entry point functions */
extern FUNC(void, RoofHatch_HMICtrl_CODE) RE_RoofHatch_HMCtrl_10ms(void);
extern FUNC(void, RoofHatch_HMICtrl_CODE) RE_RoofHatch_HMCtrl_INIT(void);

#endif
