/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: RoofHatch_HMICtrl_AUTOSAR_private.h
 *
 * Code generated for Simulink model 'RoofHatch_HMICtrl_AUTOSAR'.
 *
 * Model version                  : 1.12
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Nov 13 15:19:57 2018
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_RoofHatch_HMICtrl_AUTOSAR_private_h_
#define RTW_HEADER_RoofHatch_HMICtrl_AUTOSAR_private_h_
#include "rtwtypes.h"
#endif                                 /* RTW_HEADER_RoofHatch_HMICtrl_AUTOSAR_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
