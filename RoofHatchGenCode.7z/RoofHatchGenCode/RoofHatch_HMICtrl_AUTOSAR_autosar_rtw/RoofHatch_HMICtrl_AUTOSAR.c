/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: RoofHatch_HMICtrl_AUTOSAR.c
 *
 * Code generated for Simulink model 'RoofHatch_HMICtrl_AUTOSAR'.
 *
 * Model version                  : 1.12
 * Simulink Coder version         : 9.0 (R2018b) 24-May-2018
 * C/C++ source code generated on : Tue Nov 13 15:19:57 2018
 *
 * Target selection: autosar.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "RoofHatch_HMICtrl_AUTOSAR.h"
#include "RoofHatch_HMICtrl_AUTOSAR_private.h"

/* Named constants for Chart: '<S1>/Chart' */
#define RoofHatch_HMICtr_IN_Operational ((uint8)2U)
#define RoofHatch_HM_IN_Non_Operational ((uint8)1U)

/* Block signals (default storage) */
B_RoofHatch_HMICtrl_AUTOSAR_T RoofHatch_HMICtrl_AUTOSAR_B;

/* Block states (default storage) */
DW_RoofHatch_HMICtrl_AUTOSAR_T RoofHatch_HMICtrl_AUTOSAR_DW;

/* Forward declaration for local functions */
static void RoofHatch_HM_Function_RoofHatch(void);

/* Function for Chart: '<S1>/Chart' */
static void RoofHatch_HM_Function_RoofHatch(void)
{
  uint8 tmpRead;
  uint8 tmpRead_0;
  uint8 tmpRead_1;

  /* Inport: '<Root>/RoofHatch_SwitchStatus_A3PosSwitchStatus' */
  Rte_Read_RoofHatch_SwitchStatus_A3PosSwitchStatus(&tmpRead_1);
  if (tmpRead_1 == 1) {
    RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 2U;
  } else if (tmpRead_1 == 2) {
    RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 1U;
  } else {
    /* Inport: '<Root>/BunkH1RoofhatchCloseBtn_Stat_PushButtonStatus' */
    Rte_Read_BunkH1RoofhatchCloseBtn_Stat_PushButtonStatus(&tmpRead);

    /* Inport: '<Root>/BunkH1RoofhatchOpenBtn_Stat_PushButtonStatus' */
    Rte_Read_BunkH1RoofhatchOpenBtn_Stat_PushButtonStatus(&tmpRead_0);
    if ((tmpRead_1 == 7) && (tmpRead_0 == 3) && (tmpRead == 3)) {
      RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 7U;
    } else if (tmpRead_1 == 0) {
      if ((tmpRead_0 == 1) && (tmpRead == 0)) {
        RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 2U;
      } else if ((tmpRead == 1) && (tmpRead_0 == 0)) {
        RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 1U;
      } else {
        RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 0U;
      }
    } else {
      if ((tmpRead_1 == 6) || (tmpRead_1 == 3) || (tmpRead_1 == 7)) {
        if ((tmpRead_0 == 1) && (tmpRead == 0)) {
          RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 2U;
        } else if ((tmpRead == 1) && (tmpRead_0 == 0)) {
          RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 1U;
        } else if ((tmpRead_0 == 1) && (tmpRead == 1)) {
          RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 0U;
        } else if ((tmpRead_0 == 0) && (tmpRead == 0)) {
          RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 0U;
        } else if ((tmpRead_0 == 3) && (tmpRead == 2)) {
          RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 6U;
        } else if ((tmpRead_0 == 2) && (tmpRead == 3)) {
          RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 6U;
        } else if ((tmpRead_0 == 2) && (tmpRead == 2)) {
          RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 6U;
        } else {
          if ((tmpRead_0 == 3) && (tmpRead == 3)) {
            RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 6U;
          }
        }
      }
    }
  }
}

/* Model step function */
void RE_RoofHatch_HMCtrl_10ms(void)
{
  uint8 tmpRead;

  /* Outputs for Atomic SubSystem: '<Root>/RE_RoofHatch_HMCtrl_10ms_sys' */
  /* Chart: '<S1>/Chart' incorporates:
   *  Inport: '<Root>/Vmode_Vmode'
   */
  if (RoofHatch_HMICtrl_AUTOSAR_DW.is_active_c1_RoofHatch_HMICtrl_ == 0U) {
    RoofHatch_HMICtrl_AUTOSAR_DW.is_active_c1_RoofHatch_HMICtrl_ = 1U;
    RoofHatch_HMICtrl_AUTOSAR_DW.is_c1_RoofHatch_HMICtrl_AUTOSAR =
      RoofHatch_HM_IN_Non_Operational;
  } else {
    Rte_Read_Vmode_Vmode(&tmpRead);
    if (RoofHatch_HMICtrl_AUTOSAR_DW.is_c1_RoofHatch_HMICtrl_AUTOSAR ==
        RoofHatch_HM_IN_Non_Operational) {
      if ((tmpRead == 2) || (tmpRead == 3) || (tmpRead == 5) || (tmpRead == 6))
      {
        RoofHatch_HMICtrl_AUTOSAR_DW.is_c1_RoofHatch_HMICtrl_AUTOSAR =
          RoofHatch_HMICtr_IN_Operational;
        RoofHatch_HM_Function_RoofHatch();
      }
    } else if ((tmpRead == 0) || (tmpRead == 1) || (tmpRead == 4)) {
      RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst = 7U;
      RoofHatch_HMICtrl_AUTOSAR_DW.is_c1_RoofHatch_HMICtrl_AUTOSAR =
        RoofHatch_HM_IN_Non_Operational;
    } else {
      RoofHatch_HM_Function_RoofHatch();
    }
  }

  /* End of Chart: '<S1>/Chart' */
  /* End of Outputs for SubSystem: '<Root>/RE_RoofHatch_HMCtrl_10ms_sys' */

  /* Outport: '<Root>/RoofHatch_HMI_rqst_RoofHatch_HMI_rqst' */
  (void) Rte_Write_RoofHatch_HMI_rqst_RoofHatch_HMI_rqst
    (RoofHatch_HMICtrl_AUTOSAR_B.RoofHatch_HMI_rqst);
}

/* Model initialize function */
void RE_RoofHatch_HMCtrl_INIT(void)
{
  /* (no initialization code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
